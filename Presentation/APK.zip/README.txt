Для игры требуется от 3 до 5 устройств (игроков).
Аккаунты:
Логины:
tester1
tester2
tester3
tester4
tester5
tester6
Пароли:
У всех пароль rootToor1!